# 导入itchat包
import itchat
# 登录微信，这个过程会出现弹出一个二维码，扫描即可
# hotReload = True表示保持登陆状态。
itchat.auto_login(hotReload = True)
# get_friends()函数获取好友列表
friends = itchat.get_friends(update = True)[0:]
# 打印出好友列表，如果是python2的话应该是print friends
print(friends)
## 然后你会发现这个数据格式不是我们熟悉的数据格式，接下来
## 我们用下面一段代码把好友列表导出为csv文件:
def get_var(var):
    variable = []
    for i in friends:
        value = i[var]
        variable.append(value)
    return variable
# 昵称(也就是我们给好友的备注)
Nickname = get_var("NickName")
# 好友的性别
Sex = get_var("Sex")
# 好友微信上显示的省份
Province = get_var("Province")
# 好友微信上显示的市
City = get_var("City")
# 好友的微信个性签名
Signature = get_var("Signature")
# 好友的微信名称
RemarkName = get_var("RemarkName")
# 导入pandas包的DataFrame
from pandas import DataFrame
data = {'NickName': Nickname,
        'Sex': Sex,
        'Province': Province,
        'City': City,
        'Signature': Signature,
        'RemarkName': RemarkName
        }
frame = DataFrame(data)
frame.to_csv('我的好友列表.csv', index = True, encoding = 'utf-8')
